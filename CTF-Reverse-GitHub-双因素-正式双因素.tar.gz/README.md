# GitHub 双因素逆向题候选集

本目录收集从 GitHub 公开仓库筛选出的 CTF/逆向题目，按 P1–P4 保护因素登记。当前以“题目数”和“二进制文件数”分开统计，x86/x64 只算一个题目、两个文件。

## 分类口径

- P1 Block：反调试、反虚拟机、反跟踪、断点/完整性检查等分析阻断。
- P2 Obfuscate：控制流/数据/字符串混淆、花指令、垃圾代码、不透明谓词、诱导路径等。
- P3 Morph：自修改、运行时解密/重写、代码注入、静态与运行时形态变化等。
- P4 Conceal：加壳、压缩/加密封装、虚拟机保护/虚拟化执行等。

反调试和反虚拟机都属于 P1，不能因为同时出现就计成两个因素。只有证据落在两个不同因素族的题目才进入正式双因素清单。

## 当前数量

- 正式双因素：16 个不同题目，17 个原始二进制文件。
- 主组合：P1+P2 为 8 个题目、9 个文件；P1+P3 为 3 个题目、3 个文件；P1+P4 为 1 个题目、1 个文件；P2+P4 为 1 个题目、1 个文件；P2+P3 为 1 个题目、1 个文件；P3+P4 为 2 个题目、2 个文件。
- 多因素题：Squirtle、BBzFirstMalware、Organised Person，已经分别放入主组合目录，同时在 `多因素/` 中保留一份便于抽样。
- 源码/待复核候选：Ouroboros、Loki、Google CTF Polymorph、Google CTF Eldar。
- 单因素参考：SECCON Anti-Debugging Reverse 100、FuelVM、XMan OLLVM；这些不计入双因素数量。

## 目录说明

- `P1+P2/`、`P1+P3/`、`P1+P4/`、`P2+P3/`、`P2+P4/`、`P3+P4/`：正式双因素二进制。
- `多因素/`：已经确认同时涉及三个或更多因素的题目副本。
- `待复核/`：尚不能稳定证明第二个因素族，或只有源码/参考用途的候选。
- `辅助文件/`：服务端等不作为逆向目标的配套文件。
- `github-dual-factor-manifest.tsv`：来源、文件类型、大小、SHA-256、因素证据和复核状态。

## 已确认的主要来源

- [PUXSY Reverse-Engineering-CTF](https://github.com/PUXSY/Reverse-Engineering-CTF)：Level 8/9/10/13。
- [PlayBoiSK8/HuanBui_CTF](https://github.com/PlayBoiSK8/HuanBui_CTF)：PC_Check.exe。
- [ntddk/AntiqueRev](https://github.com/ntddk/AntiqueRev)：Security Camp 2014 Reverse 400。
- [Panca2022/reverse-engineering-ctf](https://github.com/Panca2022/reverse-engineering-ctf)：Encrypted Message。
- [knewstimek/crackme-agent-bench](https://github.com/knewstimek/crackme-agent-bench)：v2 的 x86/x64 变体；v1 暂列待复核。
- [Google CTF 2018 re-drm](https://github.com/google/google-ctf/tree/main/2018/finals/re-drm)：ASPARAGUS。
- [PKU GeekGame 5th binary-ffi](https://github.com/PKU-GeekGame/geekgame-5th/tree/master/official_writeup/binary-ffi)：binary-ffi。
- [LabyREnth materials](https://github.com/nullsector/ctf)：AntiD、Squirtle、BBzFirstMalware。
- [Pasticciotto / PoliCTF VM](https://github.com/peperunas/pasticciotto)：client.elf。
- [KITCTFCTF 2022 protector](https://github.com/maulvialf/CTF-Challs-Archive/tree/main/2022/KITCTFCTF/rev/protector)：分块运行时解密、执行后重新加密的自定义保护题。
- [NUS Greyhats Welcome CTF 2025 Organised Person](https://github.com/NUSGreyhats/welcome-ctf-2025-public/tree/main/rev/organised_person)：custom packer，运行时解密并重建内嵌 PE。

## 使用注意

1. Windows PE 题需要 Windows 虚拟机或 Wine；Linux ELF 题需要 Linux 环境。不要在宿主机直接运行来历不明的 PE/ELF。
2. `binary-ffi`、LabyREnth 等公开仓库通常同时提供 write-up 或 flag 线索。论文实验时应把 write-up、解题脚本和 flag 文件排除在模型输入之外。
3. GitHub 可访问不等于自动获得再分发许可。尤其是 LabyREnth 赛事材料，公开数据集发布前应单独核对授权；`github-dual-factor-manifest.tsv` 中的来源链接和哈希用于复核。
4. `待复核` 和“单因素参考”不计入正式双因素数量，除非后续完成逐题源码/二进制对应关系复核。
